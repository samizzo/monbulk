package monbulk.android;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;

import org.apache.cordova.*;

public class MonbulkDroidActivity extends DroidGap {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.main);
        init();
        super.setIntegerProperty("loadUrlTimeoutValue", 6000);
        super.loadUrl("file:///android_asset/www/Monbulk.html");
    }
    @Override
    public void init() {
    super.init(new WebView(this), new GWTCordovaWebViewClient(this), new CordovaChromeClient(this));
    }
}